from src.dataforge.importProject import ImportProject
from src.dataforge.mainConfig import MainConfig


def main():
    conf = MainConfig()
    imp = ImportProject(conf)
    imp.load()


if __name__ == '__main__':
    main()
